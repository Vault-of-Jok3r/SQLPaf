# SQLPaf 
*SQL Penetration Assistant Framework*

By :
- Vault-of-Jok3r : Léo Dardillac
- Zap2204        : Adrien Moncet

## Commandes pour commit :

```git
git add .
git status
git commit
git push
```

## Commandes pour mettre à jour son code :

```git
git pull
```

<span style="color: #FF0000">Deadline mercredi 20 mars 2025 à 23:59</span>
